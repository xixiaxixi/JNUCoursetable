package com.wjiangnan.tiaoshi;

import cclovecc.*;

public class Cao {
    public static void main(String[] args) throws Exception {

        ZhengFangUrlFactory.initUrl("JNUD5");
        ZhengFangCookie.initCookie();

        Login.getInstance().setUserName("xxx")
                .setKey("***");

        LoginState state = Login.getInstance().login();

        switch (state) {
            case SUCCESS:
                CourseTable courseTable = MainPage.getInstance().getCourseTable();
                //我的思路是mainPage是通向一切的接口
                //但为什么下面变成CourseTable的方法了呢？
                //因为mainPage只是个小工厂，courseTable改变由他自身来
                //好吧编不下去了，其实就是我菜
                Thread.sleep(3100);
                CourseTable courseTable2 = courseTable.changeTerm(1);
                Thread.sleep(3100);
                CourseTable courseTable3 = courseTable2.changeYear(2016);//输入第一年的年份

                System.out.println(courseTable3.getTable());
        }
    }
}
