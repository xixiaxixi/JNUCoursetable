package cclovecc;

public enum LoginState {
    SUCCESS,
    CHECKCODE_ERROR,
    USER_DOESNOT_EXIST,
    PASSWORD_ERRER,
    UNKNOWN_ERROR
}
