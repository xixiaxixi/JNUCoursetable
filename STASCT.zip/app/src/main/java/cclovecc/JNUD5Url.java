package cclovecc;

public class JNUD5Url extends ZhengFangUrl{
    public JNUD5Url(){
        URL_LOGIN = "http://202.195.144.163/jndx/default5.aspx";
        URL_LOGIN_REQUEST = "http://202.195.144.163/jndx/default5.aspx";
        REFERER_LOGIN_REQUEST = "http://202.195.144.163/jndx/default5.aspx";
        URL_BASE = "http://202.195.144.163/jndx/";
        REFERER__MAINPAGE_BASE = "http://202.195.144.163/jndx/xs_main.aspx?xh=";


        instance = this;
    }
}
